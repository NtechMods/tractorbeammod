﻿using System;

namespace Cython.EnergyWeapons
{
	public static class EnergyWeaponManager
	{
		public static AttractorWeaponInfo largeBlockAttractorTurret = new AttractorWeaponInfo(12f, 10f , "LargeAttractorEnergyCell", 1, 1000f, 30f, 20f, 100, 10);
		
		
	}
	
}

